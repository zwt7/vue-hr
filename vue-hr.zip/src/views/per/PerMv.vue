<template>
  <div>员工调动</div>
</template>

<script>
export default {
  name: "PerMv",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>