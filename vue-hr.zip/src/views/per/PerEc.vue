<template>
  <div>员工奖惩</div>
</template>

<script>
export default {
  name: "PerEc",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>