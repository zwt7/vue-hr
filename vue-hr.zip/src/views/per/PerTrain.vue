<template>
  <div>员工培训</div>
</template>

<script>
export default {
  name: "PerTrain",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>