<template>
  <div>员工调薪</div>
</template>

<script>
export default {
  name: "PerSalary",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>