<template>
  <div>员工积分统计</div>
</template>

<script>
export default {
  name: "StaSore",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>