<template>
  <div>工资账套管理</div>
</template>

<script>
export default {
  name: "SalSobMan",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>