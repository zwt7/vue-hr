<template>
  <div>工资表管理</div>
</template>

<script>
export default {
  name: "SalTable",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>