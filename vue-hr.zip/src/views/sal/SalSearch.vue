<template>
  <div>工资表查询</div>
</template>

<script>
export default {
  name: "SalSearch",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>