<template>
  <div>工资账套设置</div>
</template>

<script>
export default {
  name: "SalSobSett",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>