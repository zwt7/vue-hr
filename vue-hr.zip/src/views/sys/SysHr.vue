<template>
  <div>操作员管理</div>
</template>

<script>
export default {
  name: "SysHr",
  data() {
    return {};
  }
};
</script>

<style scoped >
</style>