<template>
  <div>初始化数据库</div>
</template>

<script>
export default {
  name: "SysInit",
  data() {
    return {};
  }
};
</script>

<style scoped >
</style>