<template>
  <div>系统管理</div>
</template>

<script>
export default {
  name: "SysCfg",
  data() {
    return {};
  }
};
</script>

<style scoped >
</style>