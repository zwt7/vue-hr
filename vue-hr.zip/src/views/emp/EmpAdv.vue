<template>
  <div>高级资源</div>
</template>

<script>
export default {
  name: "EmpAdv",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>
