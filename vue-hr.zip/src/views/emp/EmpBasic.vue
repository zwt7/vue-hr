<template>
  <div>基本资料</div>
</template>

<script>
export default {
  name: "EmpBasic",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
</style>
