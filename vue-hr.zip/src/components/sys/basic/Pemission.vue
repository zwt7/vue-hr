<template>
  <div>
      <!-- 头部 -->
    <div class="permission_input" style="text-align: left;">
      <el-input placeholder="请输入角色英文名" v-model="role.name" size="small">
        <template slot="prepend">ROLE_</template>
      </el-input>
      <el-input v-model="role.nameZh" placeholder="请输入角色中文名" size="small"></el-input>
      <el-button type="primary" size="mini" style="margin-left: 5px;" @click="addRole" @keydown.enter.native="addRole">
         添加角色
      </el-button>
    </div>
    <div class="permission_main">
      <el-collapse v-model="activeName" accordion size="small" @change="changeMenu">
        <el-collapse-item :title="item.nameZh" :name="item.id" v-for="(item,index) in roles" :key="index">
          <el-card class="box-card">
            <div slot="header" class="clearfix">
              <span>可访问资源</span>
              <el-button style="float:rigth;padding:3px 0; color:#ff0000" icon="el-icon-delete" @click="deleteRole(item)"></el-button>
            </div>
            <div>
              <el-tree show-checkbox node-key="id" :props="defaultProps" ref="tree" :key="index" :data="allMenus"
               :default-checked-keys="selectedMenus">
              </el-tree>
              <div style="display:flex; justfy-content:flex-end">
                <el-button size="mini" @click="cancelUpdate">取消修改</el-button>
                <el-button size="mini" type="primary" @click="doUpdate(item.id,index)">确认修改</el-button>
              </div>
            </div>
          </el-card>
        </el-collapse-item>

      </el-collapse>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      role:{
        name:'',
        nameZh:''
      },
      //面板激活项
      activeName:-1,
      //角色数组
      roles:[],
      //每个角色权限的数据
      allMenus:[],
      //数据配置项名称与后端数据的属性名称匹配 
      defaultProps:{
        children:'children',
        label:'name'
      },
      //选中菜单的id数据
      selectedMenus:[]    
    };
  },
  mounted(){
    this.initRoles()
  },
 methods:{
   initRoles() {
     this.getRequest('/system/basic/permiss').then(resp =>{
       if(resp){
         this.roles=resp.obj
       }
     })
   },
   changeMenu(rid){
     if(rid){
       this.initMenus()
       this.initSelectedMenus(rid)
     }
   },
   //初始化三级菜单列表
   initAllMenus(){
     this.getRequest('/system/basic/permiss/menus').then(resp =>{
       if(resp){
         this.allMenus=resp.obj
       }
     })
   }
 }
};
</script>

<style scoped>

</style>
